import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static("public"));

app.post("/chat", async (req, res) => {
  const userMessage = req.body.message.toLowerCase();

  let reply = "I'm Lyra AI 🤖 How can I help you?";

  if (userMessage.includes("price") || userMessage.includes("cost")) {
    reply = `
💰 Pricing:
• Website: ₹4000+
• AI Chatbot: ₹4000–₹6000
• Full Package: ₹5000
    `;
  } 
  else if (userMessage.includes("website")) {
    reply = "We build modern, fast, and AI-powered websites starting at ₹4000 🚀";
  }
  else if (userMessage.includes("chatbot")) {
    reply = "Our AI chatbots automate your business and cost ₹4000–₹6000 🤖";
  }
  else if (userMessage.includes("contact")) {
    reply = "📞 WhatsApp: 7658008604\n📸 Instagram: @arshan_sidhu6";
  }
  else {
    reply = "Tell me what you need 😊 (website, chatbot, pricing, contact)";
  }

  res.json({ reply });
});

app.listen(process.env.PORT, () => {
  console.log(`Server running on http://localhost:${process.env.PORT}`);
});